//
//  EventItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class EventItems{
    static var eventImages : [String] = ["Event1", "Event2", "Event3", "Event4"]
    static var eventTitle : [String] = ["Event1", "Event2", "Event3", "Event4"]
    static var eventDate : [String] = ["15/08/2018", "21/09/2018", "31/12/2018", "04/09/2018"]
    static var eventLocation : [String] = ["Toronto", "Vancouver", "London", "Sydney"]
    static var eventDescription : [String] = ["Description of Event111111 of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
        "Description of Event22222222 dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
        "Description of Event33333333 text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.",
        "Description of Event444444 text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged."]
}
