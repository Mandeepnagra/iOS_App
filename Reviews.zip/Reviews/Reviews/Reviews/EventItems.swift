//
//  EventItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class EventItems{
    static var eventImages : [String] = ["Event1", "Event2", "Event3", "Event4"]
    static var eventTitle : [String] = ["Bhangra Night", "New Year Eve", "Sing Your Lungs", "Games in city"]
    static var eventDate : [String] = ["15/08/2018", "31/12/2018", "1/9/2018", "04/09/2018"]
    static var eventLocation : [String] = ["Toronto", "Vancouver", "London", "Sydney"]
    static var eventDescription : [String] = ["Walk through the history of Toronto as we explore the hidden gems of the St. Lawrence Neighbourhood, once the Old Town of York, and connect today’s bustling city with remnants from the past. Provides a great introduction to the city for newcomers, with interesting and little-known stories for those who already call Toronto home.",
        "Walk through the history of Toronto as we explore the hidden gems of the St. Lawrence Neighbourhood, once the Old Town of York, and connect today’s bustling city with remnants from the past. Provides a great introduction to the city for newcomers, with interesting and little-known stories for those who already call Toronto home.",
        "Walk through the history of Toronto as we explore the hidden gems of the St. Lawrence Neighbourhood, once the Old Town of York, and connect today’s bustling city with remnants from the past. Provides a great introduction to the city for newcomers, with interesting and little-known stories for those who already call Toronto home.",
        "Walk through the history of Toronto as we explore the hidden gems of the St. Lawrence Neighbourhood, once the Old Town of York, and connect today’s bustling city with remnants from the past. Provides a great introduction to the city for newcomers, with interesting and little-known stories for those who already call Toronto home."]
}


