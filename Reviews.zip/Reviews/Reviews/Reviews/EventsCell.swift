//
//  EventsCell.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class EventsCell: UICollectionViewCell {
    
    @IBOutlet weak var imgEvent: UIImageView!    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
}
