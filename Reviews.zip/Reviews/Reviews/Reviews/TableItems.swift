//
//  TableItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Logo{
    static var logo: [String] = ["logo","bg"]
}

class TableItems{
    static var titles: [String] = ["Location", "Contacts"]
    static var subTitles: [String] = ["Time is not yours gh rgru er gygtygt rggtyg hgrgtet grtggu ghu", "Be Everywhere gtryt euyrret9t ryrt7 uygrugyu ggr9 dfgr"]
    static var images: [String] = ["logo","logo"]
}
