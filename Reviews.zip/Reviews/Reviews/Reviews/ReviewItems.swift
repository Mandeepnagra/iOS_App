//
//  ReviewItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class ReviewItems {
    static var userName : [String] = []
    static var userReview : [String] = []
}
