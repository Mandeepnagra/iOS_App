//
//  ReviewItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class ReviewItems0 {
    static var userName : [String] = ["Ryan Keeling","Yusuf","Nairra"]
    static var userReview : [String] = ["Wet Will Always Dry could have been a double EP, but an album release at least shines a brighter spotlight on one of modern techno's leading artists.","As such, Melt is a blast. The experience was heightened this year thanks to a few major tweaks to the main site, in addition to spotless weather.","There is a distinct lack of coherence in the album's aesthetic fluidity, but it's more exciting than it is jarring."]
}

class ReviewItems1 {
    static var userName : [String] = ["Ryan Keeling","Yusuf","Nairra"]
    static var userReview : [String] = ["Wet Will Always Dry could have been a double EP, but an album release at least shines a brighter spotlight on one of modern techno's leading artists.","As such, Melt is a blast. The experience was heightened this year thanks to a few major tweaks to the main site, in addition to spotless weather.","There is a distinct lack of coherence in the album's aesthetic fluidity, but it's more exciting than it is jarring."]
}

class ReviewItems2 {
    static var userName : [String] = ["Ryan Keeling","Yusuf","Nairra"]
    static var userReview : [String] = ["Wet Will Always Dry could have been a double EP, but an album release at least shines a brighter spotlight on one of modern techno's leading artists.","As such, Melt is a blast. The experience was heightened this year thanks to a few major tweaks to the main site, in addition to spotless weather.","There is a distinct lack of coherence in the album's aesthetic fluidity, but it's more exciting than it is jarring."]
}


class ReviewItems3 {
    static var userName : [String] = ["Ryan Keeling","Yusuf","Nairra"]
    static var userReview : [String] = ["Wet Will Always Dry could have been a double EP, but an album release at least shines a brighter spotlight on one of modern techno's leading artists.","As such, Melt is a blast. The experience was heightened this year thanks to a few major tweaks to the main site, in addition to spotless weather.","There is a distinct lack of coherence in the album's aesthetic fluidity, but it's more exciting than it is jarring."]
}
