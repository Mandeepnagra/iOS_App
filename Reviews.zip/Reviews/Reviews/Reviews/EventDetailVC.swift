//
//  EventDetailVC.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CallKit
import MessageUI
import AVKit
class EventDetailVC: UIViewController {
    var video = AVPlayer()
    var videoPlayer = AVPlayerViewController()
    @IBOutlet weak var lblEventTitle: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var lblEventDateTitle: UILabel!
    @IBOutlet weak var lblEventLocationTitle: UILabel!
    @IBOutlet weak var lblContactInformationTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblContactInformation: UILabel!
    @IBOutlet weak var lblReviewsTitle: UILabel!
    @IBOutlet weak var lblAddReviewTitle: UILabel!
    @IBOutlet weak var txtReview: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var lblSeeAllReviews: UILabel!
    
    @IBAction func btnVideo(_ sender: Any) {
        
        if let path = Bundle.main.path(forResource: "Toronto", ofType: "mp4"){
            
            self.video = AVPlayer(url: URL(fileURLWithPath: path))
            self.videoPlayer = AVPlayerViewController()
            self.videoPlayer.player = video
            
            self.present(self.videoPlayer, animated: true, completion: {
                self.video.play()
            })
        }
    }
    //@IBOutlet weak var segmentContact: UISegmentedControl!
    
    
    var selectedEvent: Int?
    
    @IBAction func btnSeeAllReviews(_ sender: UIButton) {
        showReviews()
    }
    
    
    @IBAction func btnCall(_ sender: UIButton) {
        print("Calling")
        let url = URL(string: "tel://+1647219483")
        
        if UIApplication.shared.canOpenURL(url!)
        {
            if #available(iOS 10, *)
            {
                UIApplication.shared.open(url!)
            }
            else
            {
                UIApplication.shared.openURL(url!)
            }
        }
        
    }
    
    @IBAction func btnSMS(_ sender: UIButton) {
        print("Sending SMS")
        let url = URL(string: "tel://+16472194983")
        if UIApplication.shared.canOpenURL(url!)
        {
            if #available(iOS 10, *)
            {
                UIApplication.shared.open(url!)
            }
            else
            {
                UIApplication.shared.openURL(url!)
            }
        }
    }
    
    @IBAction func btnSubmitReview(_ sender: UIButton) {
        if txtEmail.text != "" && txtReview.text != ""{
            if selectedEvent == 0{
                ReviewItems0.userName.insert("\(txtEmail.text!)", at:0)
                ReviewItems0.userReview.insert("\(txtReview.text!)", at:0)
            }else if selectedEvent == 1{
                ReviewItems1.userName.insert("\(txtEmail.text!)", at:0)
                ReviewItems1.userReview.insert("\(txtReview.text!)", at:0)
            }else if selectedEvent == 2{
                ReviewItems2.userName.insert("\(txtEmail.text!)", at:0)
                ReviewItems2.userReview.insert("\(txtReview.text!)", at:0)
            }else if selectedEvent == 3{
                ReviewItems3.userName.insert("\(txtEmail.text!)", at:0)
                ReviewItems3.userReview.insert("\(txtReview.text!)", at:0)
            }
            
            alert()
        }else{
            alertEmptyFields()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if selectedEvent != nil{
            displayValues()
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayValues(){
        
        lblEventTitle.text = EventItems.eventTitle[self.selectedEvent!]
        txtDescription.text = EventItems.eventDescription[self.selectedEvent!]
        lblDate.text = EventItems.eventDate[self.selectedEvent!]
        lblLocation.text = EventItems.eventLocation[self.selectedEvent!]
    }
    
    
    func alert(){
        
        let infoAlert = UIAlertController(title: "Review Submitted", message: nil, preferredStyle: .alert)
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
            self.cancel()
        }))
        infoAlert.addAction(UIAlertAction(title: "Show Reviews", style: .default, handler: { action in
            self.showReviews()
        }))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    func cancel(){
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeVC = mainSB.instantiateViewController(withIdentifier: "EventDetailScene")
        navigationController?.pushViewController(homeVC, animated: true)
    }
    
    func showReviews(){
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeVC = mainSB.instantiateViewController(withIdentifier: "ReviewsScene") as! ReviewsTVC
        homeVC.selectedEvent = selectedEvent
        navigationController?.pushViewController(homeVC, animated: true)
    }
    
    func alertEmptyFields(){
        let infoAlert = UIAlertController(title: "All fields are required", message: nil, preferredStyle: .alert)
        infoAlert.addAction(UIAlertAction(title: "Okay!", style: .cancel, handler: nil ))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}

extension EventDetailVC: MFMailComposeViewControllerDelegate{
    private func mailComposeController(controller: MFMailComposeViewController,
                               didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        // Check the result or perform other tasks.
        // Dismiss the mail compose view controller.
        controller.dismiss(animated: true, completion: nil)
    }
}
