//
//  EventDetailVC.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class EventDetailVC: UIViewController {

    @IBOutlet weak var lblEventTitle: UILabel!
    @IBOutlet weak var txtDescription: UITextView!
    @IBOutlet weak var lblEventDateTitle: UILabel!
    @IBOutlet weak var lblEventLocationTitle: UILabel!
    @IBOutlet weak var lblContactInformationTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblContactInformation: UILabel!
    @IBOutlet weak var lblReviewsTitle: UILabel!
    @IBOutlet weak var lblAddReviewTitle: UILabel!
    @IBOutlet weak var txtReview: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var lblSeeAllReviews: UILabel!
    
    @IBOutlet weak var segmentContact: UISegmentedControl!
    
    var selectedEvent: Int?
    
    @IBAction func btnSeeAllReviews(_ sender: UIButton) {
    }
    
    @IBAction func btnSubmitReview(_ sender: UIButton) {
        ReviewItems.userName.append("\(txtEmail.text!)")
        ReviewItems.userReview.append("\(txtReview.text!)")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let infoAlert = UIAlertController(title: "Confirm Details", message: "data", preferredStyle: .alert)
//        
//        switch segmentContact.selectedSegmentIndex {
//            
//        case 0:
//            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            self.present(infoAlert, animated: true, completion: nil)
//            
//        case 1:
//            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            self.present(infoAlert, animated: true, completion: nil)
//            
//        case 2:
//            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            self.present(infoAlert, animated: true, completion: nil)
//            
//        default:
//            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            self.present(infoAlert, animated: true, completion: nil)
//        }
        
        if selectedEvent != nil{
            displayValues()
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayValues(){
        
        lblEventTitle.text = EventItems.eventTitle[self.selectedEvent!]
        txtDescription.text = EventItems.eventDescription[self.selectedEvent!]
        lblDate.text = EventItems.eventDate[self.selectedEvent!]
        lblLocation.text = EventItems.eventLocation[self.selectedEvent!]
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
